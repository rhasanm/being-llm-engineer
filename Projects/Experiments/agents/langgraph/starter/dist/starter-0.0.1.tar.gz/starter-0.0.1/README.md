# starter

[![PyPI - Version](https://img.shields.io/pypi/v/starter.svg)](https://pypi.org/project/starter)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/starter.svg)](https://pypi.org/project/starter)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install starter
```

## License

`starter` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
